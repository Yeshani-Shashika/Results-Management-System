package com.nibm.resultmanagement.stunlect.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.nibm.resultmanagement.R;

public class ViewResult extends AppCompatActivity {

    TextView index, bc, net, ct, dbms, gui, intro, oop1, oop2, pf, qt, se, ss, wad, fp;

    FirebaseFirestore db = FirebaseFirestore.getInstance();

    String indexNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_result);

        //Get Index Number
        Intent intent = getIntent();
        indexNumber = intent.getStringExtra("indexId");

        SetUpUi();
        GetFirestoreData();
    }

    private void GetFirestoreData() {
        index.setText("Index Number : " + indexNumber);
        DocumentReference docRef = db.collection("results").document(indexNumber);
        docRef.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                DocumentSnapshot document = task.getResult();
                if (document.exists()) {
                    if (!document.getData().get("netw").equals("")) {
                        net.setText((String) document.getData().get("netw"));
                    } else {
                        net.setText("Pending");
                    }
                    if (!document.getData().get("bc").equals("")) {
                        bc.setText(document.getData().get("bc").toString());
                    } else {
                        bc.setText("Pending");
                    }
                    if (!document.getData().get("ct").toString().equals("")) {
                        ct.setText(document.getData().get("ct").toString());
                    } else {
                        ct.setText("Pending");
                    }
                    if (!document.getData().get("dbms").equals("")) {
                        dbms.setText(document.getData().get("dbms").toString());
                    } else {
                        dbms.setText("Pending");
                    }
                    if (!document.getData().get("gui").equals("")) {
                        gui.setText(document.getData().get("gui").toString());
                    } else {
                        gui.setText("Pending");
                    }
                    if (!document.getData().get("intro").equals("")) {
                        intro.setText(document.getData().get("intro").toString());
                    } else {
                        intro.setText("Pending");
                    }
                    if (!document.getData().get("oop1").equals("")) {
                        oop1.setText(document.getData().get("oop1").toString());
                    } else {
                        oop1.setText("Pending");
                    }
                    if (!document.getData().get("oop2").equals("")) {
                        oop2.setText(document.getData().get("oop2").toString());
                    } else {
                        oop2.setText("Pending");
                    }
                    if (!document.getData().get("pf").equals("")) {
                        pf.setText(document.getData().get("pf").toString());
                    } else {
                        pf.setText("Pending");
                    }
                    if (!document.getData().get("qt").equals("")) {
                        qt.setText(document.getData().get("qt").toString());
                    } else {
                        qt.setText("Pending");
                    }
                    if (!document.getData().get("se").equals("")) {
                        se.setText(document.getData().get("se").toString());
                    } else {
                        se.setText("Pending");
                    }
                    if (!document.getData().get("ss").equals("")) {
                        ss.setText(document.getData().get("ss").toString());
                    } else {
                        ss.setText("Pending");
                    }
                    if (!document.getData().get("wad").equals("")) {
                        wad.setText(document.getData().get("wad").toString());
                    } else {
                        wad.setText("Pending");
                    }
                    if (!document.getData().get("fp").equals("")) {
                        fp.setText(document.getData().get("fp").toString());
                    } else {
                        fp.setText("Pending");
                    }

                    Toast.makeText(getApplicationContext(), "Result Loaded", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getApplicationContext(), "No Result Found", Toast.LENGTH_LONG).show();
                }
            } else {
                Toast.makeText(getApplicationContext(), "Try again", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void SetUpUi() {
        index = findViewById(R.id.view_result_index);
        bc = findViewById(R.id.view_result_bc);
        net = findViewById(R.id.view_result_net);
        ct = findViewById(R.id.view_result_ct);
        dbms = findViewById(R.id.view_result_db);
        gui = findViewById(R.id.view_result_gui);
        intro = findViewById(R.id.view_result_intro);
        oop1 = findViewById(R.id.view_result_oop1);
        oop2 = findViewById(R.id.view_result_oop2);
        pf = findViewById(R.id.view_result_pf);
        qt = findViewById(R.id.view_result_qt);
        se = findViewById(R.id.view_result_se);
        ss = findViewById(R.id.view_result_ss);
        wad = findViewById(R.id.view_result_wad);
        fp = findViewById(R.id.view_result_fp);
    }
}