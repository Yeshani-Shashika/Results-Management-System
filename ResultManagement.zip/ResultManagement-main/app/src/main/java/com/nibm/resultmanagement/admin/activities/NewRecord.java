package com.nibm.resultmanagement.admin.activities;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.firestore.FirebaseFirestore;
import com.nibm.resultmanagement.R;

import java.util.HashMap;
import java.util.Map;

public class NewRecord extends AppCompatActivity {

    TextInputEditText new_recode_id, new_recode_name, new_recode_details;
    Button new_recode_button;

    FirebaseFirestore db = FirebaseFirestore.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_record);

        SetUpUi();

        new_recode_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new_recode_button.setEnabled(false);
                ValidateData();
            }
        });
    }

    private void ValidateData() {
        if (!(new_recode_id.getText().toString().trim().isEmpty())) {
            if (!(new_recode_name.getText().toString().trim().isEmpty())) {
                if (!(new_recode_details.getText().toString().trim().isEmpty())) {
                    SaveFirestoreData();
                } else {
                    Toast.makeText(getApplicationContext(), "Insert Recode Details", Toast.LENGTH_LONG).show();
                    new_recode_button.setEnabled(true);
                }
            } else {
                Toast.makeText(getApplicationContext(), "Insert Name", Toast.LENGTH_LONG).show();
                new_recode_button.setEnabled(true);
            }
        } else {
            Toast.makeText(getApplicationContext(), "Insert ID", Toast.LENGTH_LONG).show();
            new_recode_button.setEnabled(true);
        }
    }

    private void SaveFirestoreData() {
        Map<String, Object> recode = new HashMap<>();
        recode.put("id", new_recode_id.getText().toString());
        recode.put("name", new_recode_name.getText().toString());
        recode.put("details", new_recode_details.getText().toString());

        db.collection("recodes").document(new_recode_id.getText().toString())
                .set(recode)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Toast.makeText(getApplicationContext(), "Successful Add Recode", Toast.LENGTH_LONG).show();
                        new_recode_button.setEnabled(true);
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w("TAG", "Error writing document", e);
                        new_recode_button.setEnabled(true);
                    }
                });
    }

    private void SetUpUi() {
        new_recode_id = findViewById(R.id.new_recode_id);
        new_recode_name = findViewById(R.id.new_recode_name);
        new_recode_details = findViewById(R.id.new_recode_details);
        new_recode_button = findViewById(R.id.new_recode_button);
    }
}