package com.nibm.resultmanagement.model;

public class ViewComplainsModel {

    private String id;

    private String branch;

    private String date;

    private String title;

    private String description;

    public ViewComplainsModel(String id, String branch, String date, String title, String description) {
        this.id = id;
        this.branch = branch;
        this.date = date;
        this.title = title;
        this.description = description;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
