package com.nibm.resultmanagement.admin.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.nibm.resultmanagement.R;

import java.util.HashMap;
import java.util.Map;

public class UpdateRecord extends AppCompatActivity {

    TextInputEditText update_recode_id, update_recode_name, update_recode_details;
    Button update_recode_button;

    String id;

    FirebaseFirestore db = FirebaseFirestore.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_record);

        Intent intent = getIntent();
        id = intent.getStringExtra("id");

        SetUpUi();
        SetData();

        update_recode_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                update_recode_button.setEnabled(false);
                ValidateData();
            }
        });
    }

    private void SetData() {
        DocumentReference docRef = db.collection("recodes").document(id);
        docRef.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                DocumentSnapshot document = task.getResult();
                if (document.exists()) {
                    update_recode_id.setText(document.getData().get("id").toString());
                    update_recode_name.setText(document.getData().get("name").toString());
                    update_recode_details.setText(document.getData().get("details").toString());

                } else {
                    Toast.makeText(this, "Please Fill Your Data", Toast.LENGTH_LONG).show();
                }
            } else {
                Toast.makeText(this, "Try again", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void ValidateData() {
        if (!(update_recode_id.getText().toString().trim().isEmpty())) {
            if (!(update_recode_name.getText().toString().trim().isEmpty())) {
                if (!(update_recode_details.getText().toString().trim().isEmpty())) {
                    SaveFirestoreData();
                } else {
                    Toast.makeText(getApplicationContext(), "Insert Recode Details", Toast.LENGTH_LONG).show();
                    update_recode_button.setEnabled(true);
                }
            } else {
                Toast.makeText(getApplicationContext(), "Insert Name", Toast.LENGTH_LONG).show();
                update_recode_button.setEnabled(true);
            }
        } else {
            Toast.makeText(getApplicationContext(), "Insert ID", Toast.LENGTH_LONG).show();
            update_recode_button.setEnabled(true);
        }
    }

    private void SaveFirestoreData() {
        Map<String, Object> notice = new HashMap<>();
        notice.put("id", update_recode_id.getText().toString());
        notice.put("name", update_recode_name.getText().toString());
        notice.put("details", update_recode_details.getText().toString());

        db.collection("recodes").document(update_recode_id.getText().toString())
                .set(notice)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Toast.makeText(getApplicationContext(), "Successful Add Recode", Toast.LENGTH_LONG).show();
                        update_recode_button.setEnabled(true);
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w("TAG", "Error writing document", e);
                        update_recode_button.setEnabled(true);
                    }
                });
    }

    private void SetUpUi() {
        update_recode_id = findViewById(R.id.update_recode_id);
        update_recode_name = findViewById(R.id.update_recode_name);
        update_recode_details = findViewById(R.id.update_recode_details);
        update_recode_button = findViewById(R.id.update_recode_button);
    }
}