package com.nibm.resultmanagement.admin.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.nibm.resultmanagement.R;
import com.nibm.resultmanagement.model.ViewRecordModel;

import java.util.ArrayList;

public class ViewRecordAdapter extends RecyclerView.Adapter<ViewRecordAdapter.ViewRecodesViewHolder> {

    private ArrayList<ViewRecordModel> viewRecordModels;
    private OnItemClickListener mListener;

    public interface OnItemClickListener {
        void onItemClick(String id);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        mListener = listener;
    }

    class ViewRecodesViewHolder extends RecyclerView.ViewHolder {

        private TextView id, name;
        private LinearLayout linearLayout;

        public ViewRecodesViewHolder(@NonNull View itemView, final OnItemClickListener listener) {
            super(itemView);

            id = itemView.findViewById(R.id.view_recode_card_admin_id);
            name = itemView.findViewById(R.id.view_recode_card_admin_name);
            linearLayout = itemView.findViewById(R.id.view_recode_card_admin_layout);
        }
    }

    @NonNull
    @Override
    public ViewRecodesViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.view_record_admin_card,
                parent, false);
        return new ViewRecodesViewHolder(view, mListener);
    }

    public ViewRecordAdapter(ArrayList<ViewRecordModel> viewRecordModelArrayList) {
        this.viewRecordModels = viewRecordModelArrayList;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewRecodesViewHolder holder, int position) {
        ViewRecordModel viewRecordModel = viewRecordModels.get(position);

        holder.id.setText(viewRecordModel.getId());
        holder.name.setText(viewRecordModel.getName());

        holder.linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.onItemClick(viewRecordModel.getId());
            }
        });
    }

    @Override
    public int getItemCount() {
        return viewRecordModels.size();
    }
}
