package com.nibm.resultmanagement.model;

public class ViewResultModel {

    private String id;

    public ViewResultModel(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
