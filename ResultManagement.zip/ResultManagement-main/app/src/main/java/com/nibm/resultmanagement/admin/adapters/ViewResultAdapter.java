package com.nibm.resultmanagement.admin.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.nibm.resultmanagement.R;
import com.nibm.resultmanagement.model.ViewResultModel;

import java.util.ArrayList;

public class ViewResultAdapter extends RecyclerView.Adapter<ViewResultAdapter.ViewResultViewHolder> {

    private ArrayList<ViewResultModel> viewResultModels;

    class ViewResultViewHolder extends RecyclerView.ViewHolder {

        private TextView id;

        public ViewResultViewHolder(@NonNull View itemView) {
            super(itemView);

            id = itemView.findViewById(R.id.view_result_card_admin_id);
        }
    }

    @NonNull
    @Override
    public ViewResultViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.view_result_admin_card,
                parent, false);
        return new ViewResultViewHolder(view);
    }

    public ViewResultAdapter(ArrayList<ViewResultModel> viewResultModelArrayList) {
        this.viewResultModels = viewResultModelArrayList;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewResultViewHolder holder, int position) {
        ViewResultModel viewNoticeModel = viewResultModels.get(position);

        holder.id.setText(viewNoticeModel.getId());
    }

    @Override
    public int getItemCount() {
        return viewResultModels.size();
    }
}
