package com.nibm.resultmanagement.stunlect;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.nibm.resultmanagement.R;
import com.nibm.resultmanagement.database.DbHandler;
import com.nibm.resultmanagement.startup.SplashScreen;

public class StunLectHome extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener {

    //Bottom Navigation Bar to navigate fragments
    private BottomNavigationView mBtmView;

    //Load Fragments to ViewPage
    private ViewPager viewPager;

    //SQLite
    private DbHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stun_lect_home);

        SetUpUI();
        initPager();
        Logout();
    }

    //Page Setup
    private void initPager() {
        viewPager = findViewById(R.id.viewPager_stunlec);
        PageAdapterStu pageAdapterStu = new PageAdapterStu(getSupportFragmentManager());
        viewPager.setAdapter(pageAdapterStu);
        viewPager.setOffscreenPageLimit(4);

        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                switch (position) {
                    case 0:
                        mBtmView.getMenu().findItem(R.id.action_result_stu).setChecked(true);
                        break;
                    case 1:
                        mBtmView.getMenu().findItem(R.id.action_notice_stu).setChecked(true);
                        break;
                    case 2:
                        mBtmView.getMenu().findItem(R.id.action_complains_stu).setChecked(true);
                        break;
                    case 3:
                        mBtmView.getMenu().findItem(R.id.action_profile_stu).setChecked(true);
                        break;
                }
                Logout();
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    //Initialize Ui Components and Setup
    private void SetUpUI() {
        mBtmView = (BottomNavigationView) findViewById(R.id.navigation_stunlec);
        mBtmView.setOnNavigationItemSelectedListener((BottomNavigationView.OnNavigationItemSelectedListener) this);
        mBtmView.getMenu().findItem(R.id.action_result_stu).setChecked(true);
    }

    //Get Checked Bottom Navigation item and load that fragment to View Pager
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        // uncheck the other items.
        Logout();
        for (int i = 0; i < mBtmView.getMenu().size(); i++) {
            MenuItem menuItem = mBtmView.getMenu().getItem(i);
            boolean isChecked = menuItem.getItemId() == item.getItemId();
            menuItem.setChecked(isChecked);
        }

        switch (item.getItemId()) {
            case R.id.action_result_stu:
                viewPager.setCurrentItem(0);
                break;
            case R.id.action_notice_stu:
                viewPager.setCurrentItem(1);
                break;
            case R.id.action_complains_stu:
                viewPager.setCurrentItem(2);
                break;
            case R.id.action_profile_stu:
                viewPager.setCurrentItem(3);
                break;
        }
        return true;
    }

    @Override
    public void onBackPressed() {
        if (viewPager.getCurrentItem() != 0) {
            viewPager.setCurrentItem(0, true);
        } else {
            finish();
        }
    }

    private void Logout() {
        dbHandler = new DbHandler(StunLectHome.this);
        String s = dbHandler.getUser();
        Log.e("TAG", "LOGIN AS " + s);
        if (s.equals("Error")) {
            startActivity(new Intent(
                    StunLectHome.this
                    , SplashScreen.class)
                    .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            finish();
        }
    }
}