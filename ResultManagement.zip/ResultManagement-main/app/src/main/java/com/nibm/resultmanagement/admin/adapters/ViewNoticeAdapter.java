package com.nibm.resultmanagement.admin.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.nibm.resultmanagement.R;
import com.nibm.resultmanagement.model.ViewNoticeModel;

import java.util.ArrayList;

public class ViewNoticeAdapter extends RecyclerView.Adapter<ViewNoticeAdapter.ViewNoticeViewHolder> {

    private ArrayList<ViewNoticeModel> viewNoticeModels;

    class ViewNoticeViewHolder extends RecyclerView.ViewHolder {

        private TextView title, datentime, description;

        public ViewNoticeViewHolder(@NonNull View itemView) {
            super(itemView);

            title = itemView.findViewById(R.id.view_notice_card_title);
            datentime = itemView.findViewById(R.id.view_notice_card_time);
            description = itemView.findViewById(R.id.view_notice_card_description);
        }
    }

    @NonNull
    @Override
    public ViewNoticeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.view_notice_card,
                parent, false);
        return new ViewNoticeViewHolder(view);
    }

    public ViewNoticeAdapter(ArrayList<ViewNoticeModel> viewNoticeModelArrayList) {
        this.viewNoticeModels = viewNoticeModelArrayList;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewNoticeViewHolder holder, int position) {
        ViewNoticeModel viewNoticeModel = viewNoticeModels.get(position);

        holder.title.setText(viewNoticeModel.getTitle());
        holder.datentime.setText(viewNoticeModel.getDate());
        holder.description.setText(viewNoticeModel.getDescription());
    }

    @Override
    public int getItemCount() {
        return viewNoticeModels.size();
    }
}
