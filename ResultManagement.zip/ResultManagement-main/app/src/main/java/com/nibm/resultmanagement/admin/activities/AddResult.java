package com.nibm.resultmanagement.admin.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.nibm.resultmanagement.R;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class AddResult extends AppCompatActivity {
    TextInputEditText index, bc, net, ct, dbms, gui, intro, oop1, oop2, pf, qt, se, ss, wad, fp;
    Button check, submitBtn;

    FirebaseFirestore db = FirebaseFirestore.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_result);

        SetUpUi();

        check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getFirestoreData();
            }
        });

        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ValidateData();
            }
        });
    }

    private void ValidateData() {
        if (!(index.getText().toString().trim().isEmpty())) {
            SaveFirestoreData();
        } else {
            Toast.makeText(getApplicationContext(), "Insert Index Number", Toast.LENGTH_LONG).show();
        }
    }

    private void getFirestoreData() {
        DocumentReference docRef = db.collection("results").document(index.getText().toString().trim());
        docRef.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                DocumentSnapshot document = task.getResult();
                if (document.exists()) {
                    if (document.getData().get("bc") == null) {
                        bc.setText("");
                    } else {
                        bc.setText(document.getData().get("bc").toString());
                    }

                    if (document.getData().get("netw") == null) {
                        net.setText("");
                    } else {
                        net.setText(document.getData().get("netw").toString());
                    }

                    if (document.getData().get("ct") == null) {
                        ct.setText("");
                    } else {
                        ct.setText(document.getData().get("ct").toString());
                    }

                    if (document.getData().get("dbms") == null) {
                        dbms.setText("");
                    } else {
                        dbms.setText(document.getData().get("dbms").toString());
                    }

                    if (document.getData().get("gui") == null) {
                        gui.setText("");
                    } else {
                        gui.setText(document.getData().get("gui").toString());
                    }

                    if (document.getData().get("intro") == null) {
                        intro.setText("");
                    } else {
                        intro.setText(document.getData().get("intro").toString());
                    }

                    if (document.getData().get("oop1") == null) {
                        oop1.setText("");
                    } else {
                        oop1.setText(document.getData().get("oop1").toString());
                    }

                    if (document.getData().get("oop2") == null) {
                        oop2.setText("");
                    } else {
                        oop2.setText(document.getData().get("oop2").toString());
                    }

                    if (document.getData().get("pf") == null) {
                        pf.setText("");
                    } else {
                        pf.setText(document.getData().get("pf").toString());
                    }

                    if (document.getData().get("qt") == null) {
                        qt.setText("");
                    } else {
                        qt.setText(document.getData().get("qt").toString());
                    }

                    if (document.getData().get("se") == null) {
                        se.setText("");
                    } else {
                        se.setText(document.getData().get("se").toString());
                    }

                    if (document.getData().get("ss") == null) {
                        ss.setText("");
                    } else {
                        ss.setText(document.getData().get("ss").toString());
                    }

                    if (document.getData().get("wad") == null) {
                        wad.setText("");
                    } else {
                        wad.setText(document.getData().get("wad").toString());
                    }

                    if (document.getData().get("fp") == null) {
                        fp.setText("");
                    } else {
                        fp.setText(document.getData().get("fp").toString());
                    }

                    Toast.makeText(getApplicationContext(), "Result Checked", Toast.LENGTH_LONG).show();
                    submitBtn.setText("Update Result");
                } else {
                    Toast.makeText(getApplicationContext(), "No Result Found", Toast.LENGTH_LONG).show();
                }
            } else {
                Toast.makeText(getApplicationContext(), "Try again", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void SaveFirestoreData() {
        String id = getId();
        Map<String, Object> result = new HashMap<>();
        result.put("id", id);
        result.put("bc", bc.getText().toString().trim());
        result.put("netw", net.getText().toString().trim());
        result.put("ct", ct.getText().toString().trim());
        result.put("dbms", dbms.getText().toString().trim());
        result.put("gui", gui.getText().toString().trim());
        result.put("intro", intro.getText().toString().trim());
        result.put("oop1", oop1.getText().toString().trim());
        result.put("oop2", oop2.getText().toString().trim());
        result.put("pf", pf.getText().toString().trim());
        result.put("qt", qt.getText().toString().trim());
        result.put("se", se.getText().toString().trim());
        result.put("ss", ss.getText().toString().trim());
        result.put("wad", wad.getText().toString().trim());
        result.put("fp", fp.getText().toString().trim());

        db.collection("results").document(index.getText().toString().trim())
                .set(result)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Toast.makeText(getApplicationContext(), "Successful Result Submit " + index.getText().toString(), Toast.LENGTH_LONG).show();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w("TAG", "Error writing document", e);
                    }
                });
    }

    private String getId() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss", Locale.getDefault());
        return sdf.format(new Date());
    }

    private void SetUpUi() {
        index = findViewById(R.id.add_result_index);
        bc = findViewById(R.id.add_result_bc);
        net = findViewById(R.id.add_result_net);
        ct = findViewById(R.id.add_result_ct);
        dbms = findViewById(R.id.add_result_db);
        gui = findViewById(R.id.add_result_gui);
        intro = findViewById(R.id.add_result_intro);
        oop1 = findViewById(R.id.add_result_oop1);
        oop2 = findViewById(R.id.add_result_oop2);
        pf = findViewById(R.id.add_result_pf);
        qt = findViewById(R.id.add_result_qt);
        se = findViewById(R.id.add_result_se);
        ss = findViewById(R.id.add_result_ss);
        wad = findViewById(R.id.add_result_wad);
        fp = findViewById(R.id.add_result_fp);

        submitBtn = findViewById(R.id.add_result_button);
        check = findViewById(R.id.add_result_check);
    }
}