package com.nibm.resultmanagement.stunlect.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.nibm.resultmanagement.R;
import com.nibm.resultmanagement.database.DbHandler;
import com.nibm.resultmanagement.startup.SplashScreen;
import com.nibm.resultmanagement.stunlect.activities.ChangePassword;

public class ProfileFragment extends Fragment {

    Button logout, profile_changePwd;
    TextView profile_name, profile_index, profile_email, profile_branch;
    //SQLite
    private DbHandler dbHandler;

    FirebaseFirestore db = FirebaseFirestore.getInstance();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_profile, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        SetUpUi(view);
        ButtonEvent();
        GetFirestoreData();
    }

    private void GetFirestoreData() {
        dbHandler = new DbHandler(getContext());
        String user = dbHandler.getUser();
        String userId = dbHandler.getUserId();

        DocumentReference docRef = db.collection("users").document(userId);
        docRef.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                DocumentSnapshot document = task.getResult();
                if (document.exists()) {
                    profile_name.setText(document.getData().get("name").toString());
                    profile_index.setText(document.getData().get("id").toString());
                    profile_email.setText(document.getData().get("email").toString());
                    profile_branch.setText(document.getData().get("branch").toString());
                } else {
                    Toast.makeText(getContext(), "Please Fill Your Data", Toast.LENGTH_LONG).show();
                }
            } else {
                Toast.makeText(getContext(), "Try again", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void SetUpUi(View v) {
        profile_name = v.findViewById(R.id.profile_name);
        profile_index = v.findViewById(R.id.profile_index);
        profile_email = v.findViewById(R.id.profile_email);
        profile_branch = v.findViewById(R.id.profile_branch);
        logout = v.findViewById(R.id.profile_logoutButton);
        profile_changePwd = v.findViewById(R.id.profile_changePwd);
    }

    private void ButtonEvent() {
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                logout();
            }
        });

        profile_changePwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(), ChangePassword.class);
                startActivity(intent);
            }
        });
    }

    //Logout Button method implementation
    private void logout() {
        //Login Out Code Here
        //Remove Saved Login User
        dbHandler = new DbHandler(getContext());
        if (dbHandler.deleteTable()) {
            Intent restartIntent = new Intent(getContext(), SplashScreen.class);
            restartIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); //Set this flag
            startActivity(restartIntent);
        } else {
        }
    }
}