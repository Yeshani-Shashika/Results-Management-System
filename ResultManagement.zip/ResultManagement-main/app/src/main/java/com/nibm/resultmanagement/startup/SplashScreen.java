package com.nibm.resultmanagement.startup;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.ProgressBar;

import androidx.appcompat.app.AppCompatActivity;

import com.nibm.resultmanagement.R;
import com.nibm.resultmanagement.admin.AdminHome;
import com.nibm.resultmanagement.database.DbHandler;
import com.nibm.resultmanagement.stunlect.StunLectHome;

public class SplashScreen extends AppCompatActivity {
    //Progress Bar
    private ProgressBar progress_bar;
    private int i = 0;

    //SQLite
    private DbHandler dbHandler;

    private static final String TAG = "SplashScreen";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        //Full Screen
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        //screen portrait
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setContentView(R.layout.activity_splash_screen);

        progress_bar = findViewById(R.id.progress_circular);

        progress_bar.setVisibility(View.VISIBLE);
        try {
            //ProgressBar handle
            final Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (i <= 100) {
                        i++;
                        handler.postDelayed(this, 10);
                    } else {
                        //Start Menu Intent
                        dbHandler = new DbHandler(SplashScreen.this);
                        String s = dbHandler.getUser();
                        String s1 = dbHandler.getUserId();
                        Log.d("TAG", s);
                        Log.e(TAG, "LOGIN AS " + s);
                        if (s.equals("Error")) {
                            startActivity(new Intent(
                                    SplashScreen.this
                                    , Login.class)
                                    .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                        } else if (s.equals("admin")) {
                            startActivity(new Intent(
                                    SplashScreen.this
                                    , AdminHome.class)
                                    .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                        } else if (s.equals("stu")) {
                            startActivity(new Intent(
                                    SplashScreen.this
                                    , StunLectHome.class)
                                    .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                        }
                        finish();
                    }
                }
            }, 100);
        } catch (Exception e) {
            Log.e(TAG, e.toString());
        }
    }
}