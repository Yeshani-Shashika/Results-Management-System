package com.nibm.resultmanagement.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DbHandler extends SQLiteOpenHelper {

    private static final int VERSION = 1;
    private static final String DB_NAME = "result";
    private static final String TABLE_NAME = "LoginData";

    public DbHandler(@Nullable Context context) {
        super(context, DB_NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String create_table = "CREATE TABLE " + TABLE_NAME + "( " +
                "user TEXT , id TEXT);";

        db.execSQL(create_table);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }

    public void AddDB(String user, String id) {
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put("user", user);
        contentValues.put("id", id);

        sqLiteDatabase.insert(TABLE_NAME, null, contentValues);
        sqLiteDatabase.close();
    }

    public String getUser() {
        String data = "null";
        try {
            SQLiteDatabase sqLiteDatabase = getReadableDatabase();
            String query = "SELECT user FROM LoginData";
            Cursor cursor = sqLiteDatabase.rawQuery(query, null);

            cursor.moveToFirst();

            data = cursor.getString(cursor.getColumnIndex("user"));
        } catch (Exception e) {
            data = "Error";
        }
        return data;
    }

    public String getUserId() {
        String data = "null";
        try {
            SQLiteDatabase sqLiteDatabase = getReadableDatabase();
            String query = "SELECT id FROM LoginData";
            Cursor cursor = sqLiteDatabase.rawQuery(query, null);

            cursor.moveToFirst();

            data = cursor.getString(cursor.getColumnIndex("id"));
        } catch (Exception e) {
            data = "Error";
        }
        return data;
    }

    public boolean deleteTable() {
        try {
            SQLiteDatabase db = getWritableDatabase();
            db.delete(TABLE_NAME, null, null);
            db.close();
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
