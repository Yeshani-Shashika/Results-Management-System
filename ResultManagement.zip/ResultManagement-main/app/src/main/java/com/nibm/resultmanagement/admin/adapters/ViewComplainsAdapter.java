package com.nibm.resultmanagement.admin.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.nibm.resultmanagement.R;
import com.nibm.resultmanagement.model.ViewComplainsModel;

import java.util.ArrayList;

public class ViewComplainsAdapter extends RecyclerView.Adapter<ViewComplainsAdapter.ViewComplainsViewHolder> {

    private ArrayList<ViewComplainsModel> viewComplainsModels;

    class ViewComplainsViewHolder extends RecyclerView.ViewHolder {

        private TextView id, branch, date, title, description;

        public ViewComplainsViewHolder(@NonNull View itemView) {
            super(itemView);

            id = itemView.findViewById(R.id.view_complain_card_admin_id);
            branch = itemView.findViewById(R.id.view_complain_card_admin_branch);
            date = itemView.findViewById(R.id.view_complain_card_admin_date);
            title = itemView.findViewById(R.id.view_complain_card_admin_title);
            description = itemView.findViewById(R.id.view_complain_card_admin_description);
        }
    }

    @NonNull
    @Override
    public ViewComplainsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.view_complain_admin_card,
                parent, false);
        return new ViewComplainsViewHolder(view);
    }

    public ViewComplainsAdapter(ArrayList<ViewComplainsModel> viewComplainsModelArrayList) {
        this.viewComplainsModels = viewComplainsModelArrayList;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewComplainsViewHolder holder, int position) {
        ViewComplainsModel viewNoticeModel = viewComplainsModels.get(position);

        holder.id.setText(viewNoticeModel.getId());
        holder.branch.setText(viewNoticeModel.getBranch());
        holder.date.setText(viewNoticeModel.getDate());
        holder.title.setText(viewNoticeModel.getTitle());
        holder.description.setText(viewNoticeModel.getDescription());
    }

    @Override
    public int getItemCount() {
        return viewComplainsModels.size();
    }
}
