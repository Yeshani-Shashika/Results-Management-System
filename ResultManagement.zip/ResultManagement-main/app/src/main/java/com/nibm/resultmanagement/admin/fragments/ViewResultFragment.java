package com.nibm.resultmanagement.admin.fragments;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.nibm.resultmanagement.R;
import com.nibm.resultmanagement.admin.activities.AddResult;
import com.nibm.resultmanagement.admin.adapters.ViewResultAdapter;
import com.nibm.resultmanagement.model.ViewResultModel;

import java.util.ArrayList;

public class ViewResultFragment extends Fragment {

    FloatingActionButton fab;
    RecyclerView recyclerView;
    SwipeRefreshLayout mSwipeRefreshLayout;

    ViewResultAdapter viewResultAdapter;

    ArrayList<String> listId = new ArrayList<>();

    FirebaseFirestore db = FirebaseFirestore.getInstance();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_view_result, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        SetUpUi(view);
        SetUpAction();

        GetFirestoreData();

        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                GetFirestoreData();
                mSwipeRefreshLayout.setRefreshing(false);
            }
        });
    }

    private void GetFirestoreData() {
        listId.clear();

        db.collection("results").orderBy("id", Query.Direction.DESCENDING).limit(10)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Log.d("TAG", document.getId() + " => " + document.getData());

                                listId.add(document.getId());
                            }

                            InitList();
                        } else {
                            Log.d("TAG", "Error getting documents: ", task.getException());
                        }
                    }
                });
    }

    private void InitList() {
        ArrayList<ViewResultModel> arrayList = new ArrayList<>();

        if (listId.size() > 0) {
            //Temp data add to Adapter
            for (int i = 0; i < listId.size(); i++) {
                arrayList.add(new ViewResultModel(listId.get(i)));
            }
        }

        viewResultAdapter = new ViewResultAdapter(arrayList);
        viewResultAdapter.notifyDataSetChanged();
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(viewResultAdapter);

    }


    private void SetUpUi(View v) {
        fab = v.findViewById(R.id.view_result_admin_fab);
        recyclerView = v.findViewById(R.id.view_result_admin_recycle);
        mSwipeRefreshLayout = v.findViewById(R.id.view_result_admin_swipe);
    }

    private void SetUpAction() {
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(), AddResult.class);
                startActivity(intent);
            }
        });
    }
}