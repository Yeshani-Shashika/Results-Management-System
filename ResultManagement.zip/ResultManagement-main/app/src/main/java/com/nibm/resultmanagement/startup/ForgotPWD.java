package com.nibm.resultmanagement.startup;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.nibm.resultmanagement.R;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class ForgotPWD extends AppCompatActivity {

    TextInputEditText id, email;
    Button fButton;
    RadioGroup radioGroup;
    TextView pwdText;

    FirebaseFirestore db = FirebaseFirestore.getInstance();

    private static final String ALLOWED_CHARACTERS = "abcdefghijklmnopqrstuvwxyz";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_pwd);

        SetUpUi();
        fButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ValidateData();
            }
        });
    }

    private void ValidateData() {
        if (!(id.getText().toString().trim().isEmpty())) {
            if (!(email.getText().toString().trim().isEmpty())) {
                int id = radioGroup.getCheckedRadioButtonId();
                RadioButton radioButton = (RadioButton) findViewById(id);
                String text = radioButton.getText().toString();

                if (text.equals("Student and Lecture")) {
                    getStuLoginAccount();
                } else if (text.equals("Admin")) {
                    getAdminLoginAccount();
                }
            } else {
                Toast.makeText(getApplicationContext(), "Insert Email", Toast.LENGTH_LONG).show();
            }
        } else {
            Toast.makeText(getApplicationContext(), "Insert Index Number", Toast.LENGTH_LONG).show();
        }
    }

    private void getStuLoginAccount() {
        String userId = id.getText().toString();
        String userEmail = email.getText().toString();

        DocumentReference docRef = db.collection("users").document(userId);
        docRef.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                DocumentSnapshot document = task.getResult();
                if (document.exists()) {
                    if (userEmail.equals(document.getData().get("email").toString())) {
                        SetNewPassword("user");
                    } else {
                        Toast.makeText(getApplicationContext(), "Email wrong", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "Please Enter Your Index Number", Toast.LENGTH_LONG).show();
                }
            } else {
                Toast.makeText(getApplicationContext(), "Try again", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void getAdminLoginAccount() {
        String adminId = id.getText().toString();
        String adminEmail = email.getText().toString();

        DocumentReference docRef = db.collection("admin").document(adminId);
        docRef.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                DocumentSnapshot document = task.getResult();
                if (document.exists()) {
                    if (adminEmail.equals(document.getData().get("email").toString())) {
                        SetNewPassword("admin");
                    } else {
                        Toast.makeText(getApplicationContext(), "Email wrong", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "Please Enter Your Index Number", Toast.LENGTH_LONG).show();
                }
            } else {
                Toast.makeText(getApplicationContext(), "Try again", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void SetNewPassword(String account) {
        String randomPwd = getRandomString();
        Map<String, Object> user = new HashMap<>();
        user.put("password", randomPwd);

        db.collection(account).document(id.getText().toString())
                .update(user)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Toast.makeText(getApplicationContext(), "Successful saved your data", Toast.LENGTH_LONG).show();
                        pwdText.setText("Your New Password is: " + randomPwd);
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w("TAG", "Error writing document", e);
                        Toast.makeText(getApplicationContext(), "Try Again", Toast.LENGTH_LONG).show();
                    }
                });
    }

    private void SetUpUi() {
        id = findViewById(R.id.forgot_index);
        email = findViewById(R.id.forgot_email);
        fButton = findViewById(R.id.forgot_button);
        radioGroup = findViewById(R.id.forgot_radioGroup);
        pwdText = findViewById(R.id.forgot_newPWD);
    }

    private static String getRandomString() {
        final Random random = new Random();
        final StringBuilder sb = new StringBuilder(6);
        for (int i = 0; i < 6; ++i)
            sb.append(ALLOWED_CHARACTERS.charAt(random.nextInt(ALLOWED_CHARACTERS.length())));
        return sb.toString();
    }
}