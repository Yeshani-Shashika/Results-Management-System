package com.nibm.resultmanagement.startup;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.firestore.FirebaseFirestore;
import com.nibm.resultmanagement.R;

import java.util.HashMap;
import java.util.Map;

public class CreateAccount extends AppCompatActivity {

    TextInputEditText id, email, branch, name, password;
    Button register;
    FirebaseFirestore db = FirebaseFirestore.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        SetUpUi();

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ValidateData();
            }
        });

    }

    private void ValidateData() {
        if (!(id.getText().toString().trim().isEmpty())) {
            if (!(email.getText().toString().trim().isEmpty())) {
                if (!(branch.getText().toString().trim().isEmpty())) {
                    if (!(name.getText().toString().trim().isEmpty())) {
                        if (!(password.getText().toString().trim().isEmpty())) {
                            FirestoreSaveData();
                        } else {
                            Toast.makeText(getApplicationContext(), "Insert Password", Toast.LENGTH_LONG).show();
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "Insert Name", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "Insert Branch", Toast.LENGTH_LONG).show();
                }
            } else {
                Toast.makeText(getApplicationContext(), "Insert Email", Toast.LENGTH_LONG).show();
            }
        } else {
            Toast.makeText(getApplicationContext(), "Insert Index Number", Toast.LENGTH_LONG).show();
        }
    }

    private void FirestoreSaveData() {
        Map<String, Object> user = new HashMap<>();
        user.put("id", id.getText().toString());
        user.put("email", email.getText().toString());
        user.put("branch", branch.getText().toString());
        user.put("name", name.getText().toString());
        user.put("password", password.getText().toString());

        db.collection("users").document(id.getText().toString())
                .set(user)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Toast.makeText(getApplicationContext(), "Successful Created Account", Toast.LENGTH_LONG).show();
                        ClearUi();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w("TAG", "Error writing document", e);
                    }
                });
    }

    private void ClearUi() {
        id.setText("");
        email.setText("");
        branch.setText("");
        name.setText("");
        password.setText("");
        id.requestFocus();
    }

    private void SetUpUi() {
        id = findViewById(R.id.create_acc_index);
        email = findViewById(R.id.create_acc_email);
        branch = findViewById(R.id.create_acc_branch);
        name = findViewById(R.id.create_acc_name);
        password = findViewById(R.id.create_acc_password);
        register = findViewById(R.id.create_acc_button);
    }
}