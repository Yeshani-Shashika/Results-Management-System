package com.nibm.resultmanagement.stunlect.fragments;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.firestore.FirebaseFirestore;
import com.nibm.resultmanagement.R;
import com.nibm.resultmanagement.database.DbHandler;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class CreateComplainFragment extends Fragment {

    TextInputEditText create_complain_index, create_complain_title, create_complain_branch, create_complain_complain;
    Button create_complain_button;

    FirebaseFirestore db = FirebaseFirestore.getInstance();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_create_complain, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        SetUpUi(view);
        create_complain_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ValidateData();
            }
        });
    }

    private void ValidateData() {
        if (!(create_complain_index.getText().toString().trim().isEmpty())) {
            if (!(create_complain_title.getText().toString().trim().isEmpty())) {
                if (!(create_complain_branch.getText().toString().trim().isEmpty())) {
                    if (!(create_complain_complain.getText().toString().trim().isEmpty())) {
                        SaveFirestore();
                    } else {
                        Toast.makeText(getContext(), "Insert Complain", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(getContext(), "Insert Branch", Toast.LENGTH_LONG).show();
                }
            } else {
                Toast.makeText(getContext(), "Insert Title", Toast.LENGTH_LONG).show();
            }
        } else {
            Toast.makeText(getContext(), "Invalid Account", Toast.LENGTH_LONG).show();
        }
    }

    private void SaveFirestore() {
        String date = getDate();
        String time = getTime();
        String id = getUniqueId();
        Map<String, Object> complain = new HashMap<>();
        complain.put("id", create_complain_index.getText().toString());
        complain.put("index", create_complain_index.getText().toString());
        complain.put("datetime", date + " " + time);
        complain.put("title", create_complain_title.getText().toString());
        complain.put("branch", create_complain_branch.getText().toString());
        complain.put("complain", create_complain_complain.getText().toString());

        db.collection("complains").document(id)
                .set(complain)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Toast.makeText(getContext(), "Successful Add Complain", Toast.LENGTH_LONG).show();
                        ClearUi();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getContext(), "Try Again", Toast.LENGTH_LONG).show();
                        Log.w("TAG", "Error writing document", e);
                    }
                });
    }

    private String getUniqueId() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss", Locale.getDefault());
        return sdf.format(new Date());
    }

    private String getTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("HH.mm.ss", Locale.getDefault());
        return sdf.format(new Date());
    }

    private String getDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd", Locale.getDefault());
        return sdf.format(new Date());
    }

    private void ClearUi() {
        create_complain_title.setText("");
        create_complain_branch.setText("");
        create_complain_complain.setText("");
        create_complain_title.requestFocus();
    }

    private void SetUpUi(View v) {
        create_complain_index = v.findViewById(R.id.create_complain_index);
        create_complain_title = v.findViewById(R.id.create_complain_title);
        create_complain_branch = v.findViewById(R.id.create_complain_branch);
        create_complain_complain = v.findViewById(R.id.create_complain_complain);
        create_complain_button = v.findViewById(R.id.create_complain_button);

        DbHandler dbHandler;
        dbHandler = new DbHandler(getContext());
        String s = dbHandler.getUserId();
        create_complain_index.setText(s);
    }
}