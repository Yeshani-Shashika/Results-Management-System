package com.nibm.resultmanagement.startup;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.nibm.resultmanagement.R;
import com.nibm.resultmanagement.admin.AdminHome;
import com.nibm.resultmanagement.database.DbHandler;
import com.nibm.resultmanagement.stunlect.StunLectHome;

public class Login extends AppCompatActivity {

    Button login_button;
    TextView login_forgotPwd, login_create_acc;
    RadioGroup radioGroup;
    TextInputEditText id, password;

    FirebaseFirestore db = FirebaseFirestore.getInstance();

    //SQLite
    private DbHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        SetUpUi();
        ButtonEvent();
    }

    private void ButtonEvent() {
        //Login Button
        login_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!(id.getText().toString().trim().isEmpty())) {
                    if (!(password.getText().toString().trim().isEmpty())) {
                        int id = radioGroup.getCheckedRadioButtonId();
                        RadioButton radioButton = (RadioButton) findViewById(id);
                        String text = radioButton.getText().toString();

                        if (text.equals("Student and Lecture")) {
                            GetStudentAccount();
                        } else if (text.equals("Admin")) {
                            GetAdminAccount();
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "Insert Password", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "Insert Index Number", Toast.LENGTH_LONG).show();
                }
            }
        });

        //Forgot Password
        login_forgotPwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Login.this, ForgotPWD.class);
                startActivity(intent);
            }
        });

        //Create Account
        login_create_acc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Login.this, CreateAccount.class);
                startActivity(intent);
            }
        });
    }

    private void GetStudentAccount() {
        String userId = id.getText().toString();
        String userPwd = password.getText().toString();

        DocumentReference docRef = db.collection("users").document(userId);
        docRef.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                DocumentSnapshot document = task.getResult();
                if (document.exists()) {
                    if (userPwd.equals(document.getData().get("password").toString())) {
                        dbHandler = new DbHandler(Login.this);
                        if (dbHandler.deleteTable()) {
                            dbHandler.AddDB("stu", userId);
                            String s = dbHandler.getUser();
                            String s1 = dbHandler.getUserId();
                            Log.d("TAG", s + s1);
                            Intent intent = new Intent(Login.this, StunLectHome.class);
                            startActivity(intent);
                            finish();
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "Password Wrong!", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "Please Enter Your Index Number", Toast.LENGTH_LONG).show();
                }
            } else {
                Toast.makeText(getApplicationContext(), "Try again", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void GetAdminAccount() {
        String adminId = id.getText().toString();
        String adminPwd = password.getText().toString();

        DocumentReference docRef = db.collection("admin").document(adminId);
        docRef.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                DocumentSnapshot document = task.getResult();
                if (document.exists()) {
                    if (adminPwd.equals(document.getData().get("password").toString())) {
                        dbHandler = new DbHandler(Login.this);
                        if (dbHandler.deleteTable()) {
                            dbHandler.AddDB("admin", adminId);
                            String s = dbHandler.getUser();
                            String s1 = dbHandler.getUserId();
                            Log.d("TAG", s + s1);
                            Intent intent = new Intent(Login.this, AdminHome.class);
                            startActivity(intent);
                            finish();
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "Password Wrong!", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "Please Enter Your Index Number", Toast.LENGTH_LONG).show();
                }
            } else {
                Toast.makeText(getApplicationContext(), "Try again", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void SetUpUi() {
        id = findViewById(R.id.login_index);
        password = findViewById(R.id.login_password);
        login_button = findViewById(R.id.login_button);
        login_forgotPwd = findViewById(R.id.login_forgotpwd);
        login_create_acc = findViewById(R.id.login_create_acc);
        radioGroup = findViewById(R.id.login_radioGroup);
    }
}