package com.nibm.resultmanagement.stunlect;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.nibm.resultmanagement.stunlect.fragments.CreateComplainFragment;
import com.nibm.resultmanagement.stunlect.fragments.ExamResultFragment;
import com.nibm.resultmanagement.stunlect.fragments.NoticeFragment;
import com.nibm.resultmanagement.stunlect.fragments.ProfileFragment;

//Page Adapter for slide and move tabs in home
public class PageAdapterStu extends FragmentPagerAdapter {
    public PageAdapterStu(@NonNull FragmentManager fm) {
        super(fm);
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                return new ExamResultFragment();
            case 1:
                return new NoticeFragment();
            case 2:
                return new CreateComplainFragment();
            case 3:
                return new ProfileFragment();
        }
        return new ExamResultFragment();
    }

    @Override
    public int getCount() {
        return 4;
    }
}
