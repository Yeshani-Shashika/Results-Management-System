package com.nibm.resultmanagement.admin;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.nibm.resultmanagement.admin.fragments.ViewComplainsFragment;
import com.nibm.resultmanagement.admin.fragments.ViewNoticeFragment;
import com.nibm.resultmanagement.admin.fragments.ViewRecordFragment;
import com.nibm.resultmanagement.admin.fragments.ViewResultFragment;

//Page Adapter for slide and move tabs in home
public class PageAdapterAdmin extends FragmentPagerAdapter {
    public PageAdapterAdmin(@NonNull FragmentManager fm) {
        super(fm);
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                return new ViewRecordFragment();
            case 1:
                return new ViewComplainsFragment();
            case 2:
                return new ViewResultFragment();
            case 3:
                return new ViewNoticeFragment();
        }
        return new ViewRecordFragment();
    }

    @Override
    public int getCount() {
        return 4;
    }
}
