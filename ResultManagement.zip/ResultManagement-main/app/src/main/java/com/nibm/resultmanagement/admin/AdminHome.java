package com.nibm.resultmanagement.admin;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.nibm.resultmanagement.R;
import com.nibm.resultmanagement.database.DbHandler;
import com.nibm.resultmanagement.startup.SplashScreen;

public class AdminHome extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener {

    //Bottom Navigation Bar to navigate fragments
    private BottomNavigationView mBtmView;

    //Load Fragments to ViewPage
    private ViewPager viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_home);

        SetUpUI();
        initPager();
    }

    //Page Setup
    private void initPager() {
        viewPager = findViewById(R.id.viewPager_home);
        PageAdapterAdmin pageAdapterAdmin = new PageAdapterAdmin(getSupportFragmentManager());
        viewPager.setAdapter(pageAdapterAdmin);
        viewPager.setOffscreenPageLimit(4);

        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                switch (position) {
                    case 0:
                        mBtmView.getMenu().findItem(R.id.action_recode).setChecked(true);
                        break;
                    case 1:
                        mBtmView.getMenu().findItem(R.id.action_complains).setChecked(true);
                        break;
                    case 2:
                        mBtmView.getMenu().findItem(R.id.action_result).setChecked(true);
                        break;
                    case 3:
                        mBtmView.getMenu().findItem(R.id.action_notice).setChecked(true);
                        break;
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    //Initialize Ui Components and Setup
    private void SetUpUI() {
        mBtmView = (BottomNavigationView) findViewById(R.id.navigation_admin);
        mBtmView.setOnNavigationItemSelectedListener((BottomNavigationView.OnNavigationItemSelectedListener) this);
        mBtmView.getMenu().findItem(R.id.action_recode).setChecked(true);
    }

    //Get Checked Bottom Navigation item and load that fragment to View Pager
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        // uncheck the other items.
        for (int i = 0; i < mBtmView.getMenu().size(); i++) {
            MenuItem menuItem = mBtmView.getMenu().getItem(i);
            boolean isChecked = menuItem.getItemId() == item.getItemId();
            menuItem.setChecked(isChecked);
        }

        switch (item.getItemId()) {
            case R.id.action_recode:
                viewPager.setCurrentItem(0);
                break;
            case R.id.action_complains:
                viewPager.setCurrentItem(1);
                break;
            case R.id.action_result:
                viewPager.setCurrentItem(2);
                break;
            case R.id.action_notice:
                viewPager.setCurrentItem(3);
                break;
            case R.id.action_logout:
                LogOut();
                break;
        }
        return true;
    }

    private void LogOut() {
        //Login Out Code Here
        //Remove Saved Login User
        DbHandler dbHandler;
        dbHandler = new DbHandler(this);
        if (dbHandler.deleteTable()) {
            Intent restartIntent = new Intent(this, SplashScreen.class);
            restartIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); //Set this flag
            startActivity(restartIntent);
            finish();
        } else {
        }
    }

    @Override
    public void onBackPressed() {
        if (viewPager.getCurrentItem() != 0) {
            viewPager.setCurrentItem(0, true);
        } else {
            finish();
        }
    }
}
