package com.nibm.resultmanagement.stunlect.fragments;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.nibm.resultmanagement.R;
import com.nibm.resultmanagement.stunlect.activities.ViewResult;

public class ExamResultFragment extends Fragment {

    TextInputEditText exam_result_index;
    Button exam_result_button;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_exam_result, container, false);
    }

        @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        SetUpUi(view);

        exam_result_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ValidateData();
            }
        });
    }

    private void ValidateData() {
        if (!(exam_result_index.getText().toString().trim().isEmpty())) {
            Intent intent = new Intent(getContext(), ViewResult.class);
            intent.putExtra("indexId", exam_result_index.getText().toString());
            startActivity(intent);
        } else {
            Toast.makeText(getContext(), "Insert Correct Index Number", Toast.LENGTH_LONG).show();
        }
    }

    private void SetUpUi(View view) {
        exam_result_index = view.findViewById(R.id.exam_result_index);
        exam_result_button = view.findViewById(R.id.exam_result_button);
    }
}