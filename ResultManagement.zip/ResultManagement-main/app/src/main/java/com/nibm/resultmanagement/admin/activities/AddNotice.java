package com.nibm.resultmanagement.admin.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.firestore.FirebaseFirestore;
import com.nibm.resultmanagement.R;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class AddNotice extends AppCompatActivity {

    TextInputEditText title, description;
    Button submitBtn;

    FirebaseFirestore db = FirebaseFirestore.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_notice);

        SetUpUi();
        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ValidateData();
            }
        });
    }

    private void ValidateData() {
        if (!(title.getText().toString().trim().isEmpty())) {
            if (!(title.getText().toString().trim().isEmpty())) {
                SaveFireStoreData();
            }
        }
    }

    private void SaveFireStoreData() {
        String date = getDate();
        String time = getTime();
        String id = getId();

        Map<String, Object> notice = new HashMap<>();
        notice.put("title", title.getText().toString());
        notice.put("description", description.getText().toString());
        notice.put("time", time);
        notice.put("date", date);
        notice.put("id", id);

        db.collection("notices").document(id)
                .set(notice)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Toast.makeText(getApplicationContext(), "Successful Submit New Notice", Toast.LENGTH_LONG).show();
                        ClearUi();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w("TAG", "Error writing document", e);
                    }
                });
    }

    private String getId() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss", Locale.getDefault());
        return sdf.format(new Date());
    }

    private void ClearUi() {
        title.setText("");
        description.setText("");
        title.requestFocus();
    }

    private String getTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("HH.mm.ss", Locale.getDefault());
        return sdf.format(new Date());
    }

    private String getDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd", Locale.getDefault());
        return sdf.format(new Date());
    }

    private void SetUpUi() {
        title = findViewById(R.id.add_notice_title);
        description = findViewById(R.id.add_notice_note);
        submitBtn = findViewById(R.id.add_notice_button);
    }
}