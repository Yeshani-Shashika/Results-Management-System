package com.nibm.resultmanagement.stunlect.activities;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.nibm.resultmanagement.R;
import com.nibm.resultmanagement.database.DbHandler;

import java.util.HashMap;
import java.util.Map;

public class ChangePassword extends AppCompatActivity {

    TextInputEditText currentPwd, newPwd, confirmPwd;
    Button changeButton;

    FirebaseFirestore db = FirebaseFirestore.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_paasword);

        SetUpUi();

        changeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ValidateData();
            }
        });
    }

    private void ValidateData() {
        if (!(currentPwd.getText().toString().trim().isEmpty())) {
            if (!(newPwd.getText().toString().trim().isEmpty())) {
                if (!(confirmPwd.getText().toString().trim().isEmpty())) {
                    if (newPwd.getText().toString().equals(confirmPwd.getText().toString())) {
                        GetPasswordFirestore();
                    } else {
                        Toast.makeText(this, "Confirm Password Not Match", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(this, "Insert Confirm Password", Toast.LENGTH_LONG).show();
                }
            } else {
                Toast.makeText(this, "Insert New Password", Toast.LENGTH_LONG).show();
            }
        } else {
            Toast.makeText(this, "Insert Current Password", Toast.LENGTH_LONG).show();
        }
    }

    private void GetPasswordFirestore() {
        //SQLite
        DbHandler dbHandler = new DbHandler(this);
        String user = dbHandler.getUser();
        String userId = dbHandler.getUserId();

        if (user.equals("admin")) {
            user = "admin";
        } else if (user.equals("stu")) {
            user = "users";
        }

        String finalUser = user;
        String pass = currentPwd.getText().toString();

        DocumentReference docRef = db.collection(user).document(userId);
        docRef.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                DocumentSnapshot document = task.getResult();
                if (document.exists()) {
                    if (pass.equals(document.get("password").toString())) {
                        UpdatePassword(finalUser, userId);
                    } else {
                        Toast.makeText(this, "Current Password Incorrect", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(this, "Invalid User", Toast.LENGTH_LONG).show();
                }
            } else {
                Toast.makeText(this, "Try again", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void UpdatePassword(String account, String userId) {
        String newPass = newPwd.getText().toString();

        Map<String, Object> user = new HashMap<>();
        user.put("password", newPass);
        db.collection(account).document(userId)
                .update(user)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Toast.makeText(getApplicationContext(), "Successful Change Password", Toast.LENGTH_LONG).show();
                        finish();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w("TAG", "Error Change Password", e);
                    }
                });
    }

    private void SetUpUi() {
        currentPwd = findViewById(R.id.change_pwd_current);
        newPwd = findViewById(R.id.change_pwd_new);
        confirmPwd = findViewById(R.id.change_pwd_confirm);
        changeButton = findViewById(R.id.change_pwd_button);
    }
}