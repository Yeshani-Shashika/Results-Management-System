package com.nibm.resultmanagement.admin.fragments;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.nibm.resultmanagement.R;
import com.nibm.resultmanagement.admin.adapters.ViewComplainsAdapter;
import com.nibm.resultmanagement.model.ViewComplainsModel;

import java.util.ArrayList;

public class ViewComplainsFragment extends Fragment {

    RecyclerView recyclerView;
    SwipeRefreshLayout mSwipeRefreshLayout;

    ViewComplainsAdapter viewComplainsAdapter;

    ArrayList<String> listId = new ArrayList<>();
    ArrayList<String> listBranch = new ArrayList<>();
    ArrayList<String> listDate = new ArrayList<>();
    ArrayList<String> listTitle = new ArrayList<>();
    ArrayList<String> listDescription = new ArrayList<>();

    FirebaseFirestore db = FirebaseFirestore.getInstance();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_view_complains, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        SetUpUi(view);
        GetFirestoreData();

        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                GetFirestoreData();
                mSwipeRefreshLayout.setRefreshing(false);
            }
        });
    }

    private void GetFirestoreData() {
        listId.clear();
        listBranch.clear();
        listTitle.clear();
        listDescription.clear();

        db.collection("complains").orderBy("id", Query.Direction.DESCENDING)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Log.d("TAG", document.getId() + " => " + document.getData());

                                listId.add(document.get("index").toString());
                                listBranch.add(document.get("branch").toString());
                                listDate.add(document.get("datetime").toString());
                                listTitle.add(document.get("title").toString());
                                listDescription.add(document.get("complain").toString());
                            }

                            InitList();
                        } else {
                            Log.d("TAG", "Error getting documents: ", task.getException());
                        }
                    }
                });
    }

    private void InitList() {
        ArrayList<ViewComplainsModel> arrayList = new ArrayList<>();

        if (listTitle.size() > 0) {
            //Temp data add to Adapter
            for (int i = 0; i < listTitle.size(); i++) {
                arrayList.add(new ViewComplainsModel(listId.get(i), listBranch.get(i), listDate.get(i), listTitle.get(i), listDescription.get(i)));
            }
        }

        viewComplainsAdapter = new ViewComplainsAdapter(arrayList);
        viewComplainsAdapter.notifyDataSetChanged();
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(viewComplainsAdapter);

    }

    private void SetUpUi(View view) {
        recyclerView = view.findViewById(R.id.view_complain_admin_recycle);
        mSwipeRefreshLayout = view.findViewById(R.id.view_complain_admin_swipe);
    }
}