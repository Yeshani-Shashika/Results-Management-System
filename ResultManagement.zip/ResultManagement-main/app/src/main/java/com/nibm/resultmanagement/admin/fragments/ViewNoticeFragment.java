package com.nibm.resultmanagement.admin.fragments;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.nibm.resultmanagement.R;
import com.nibm.resultmanagement.admin.activities.AddNotice;
import com.nibm.resultmanagement.admin.adapters.ViewNoticeAdapter;
import com.nibm.resultmanagement.model.ViewNoticeModel;

import java.util.ArrayList;

public class ViewNoticeFragment extends Fragment {

    FloatingActionButton fab;
    SwipeRefreshLayout mSwipeRefreshLayout;

    RecyclerView recyclerView;
    ViewNoticeAdapter viewNoticeAdapter;

    ArrayList<String> listTitle = new ArrayList<>();
    ArrayList<String> listDate = new ArrayList<>();
    ArrayList<String> listDescription = new ArrayList<>();

    FirebaseFirestore db = FirebaseFirestore.getInstance();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_view_notice, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        SetUpUi(view);
        GetFirestoreData();

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(), AddNotice.class);
                startActivity(intent);
            }
        });

        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                GetFirestoreData();
                mSwipeRefreshLayout.setRefreshing(false);
            }
        });
    }

    private void GetFirestoreData() {
        listTitle.clear();
        listDate.clear();
        listDescription.clear();

        db.collection("notices").orderBy("id", Query.Direction.DESCENDING)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Log.d("TAG", document.getId() + " => " + document.getData());

                                listTitle.add(document.get("title").toString());
                                listDate.add(document.get("date").toString() + " " + document.get("time").toString());
                                listDescription.add(document.get("description").toString());
                            }

                            InitList();
                        } else {
                            Log.d("TAG", "Error getting documents: ", task.getException());
                        }
                    }
                });
    }

    private void InitList() {
        ArrayList<ViewNoticeModel> arrayList = new ArrayList<>();

        if (listTitle.size() > 0) {
            //Temp data add to Adapter
            for (int i = 0; i < listTitle.size(); i++) {
                arrayList.add(new ViewNoticeModel(listTitle.get(i), listDate.get(i), listDescription.get(i)));
            }
        }

        viewNoticeAdapter = new ViewNoticeAdapter(arrayList);
        viewNoticeAdapter.notifyDataSetChanged();
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(viewNoticeAdapter);

    }

    private void SetUpUi(View v) {
        fab = v.findViewById(R.id.view_notice_admin_fab);
        mSwipeRefreshLayout = v.findViewById(R.id.view_notice_admin_swipe);
        recyclerView = v.findViewById(R.id.view_notice_admin_recycle);
    }
}