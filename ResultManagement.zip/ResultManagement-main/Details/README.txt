Result Management System Firestore Database

users
- id
- branch
- email
- name
- password

results
- id
- subjects names

recodes
- id
- details
- name

notices
- id
- description
- date
- time
- title

complains
- id
- branch
- datetime
- index
- title
- complain

----------------------------------------------------------------

Used Libraries

//Firestore Database 
implementation 'com.google.firebase:firebase-firestore:23.0.1'

//Move Fragments
implementation "androidx.viewpager2:viewpager2:1.0.0"

//Rounded Images
implementation 'de.hdodenhof:circleimageview:3.1.0'

//Swipe down to Refresh
implementation "androidx.swiperefreshlayout:swiperefreshlayout:1.1.0"


----------------------------------------------------------------

//App Permission for Internet
<uses-permission android:name="android.permission.INTERNET" />

----------------------------------------------------------------

//Font Used
SF Pro

----------------------------------------------------------------

//In App Database use for save login information
SQLite
Database Name	: result
Table Name	: LoginData
-----------------------------------
|	user	|	id	   |
-----------------------------------
|	admin	| 	admin	   |
|	stu	| MA-DSE-201-F-011 |
-----------------------------------


----------------------------------------------------------------

App Functions
- Create Account
- Forgot Password
- Login
- Logout

- View Results
- View Notices
- Create Complain
- View Profile Details
- Change Password

- Create Recodes
- View Recodes
- Update Recodes
- View Complains
- Create Notice
- View Notices
- Add Result
- Find Results
- Update Results
- View Recent Add Results


----------------------------------------------------------------

App componants Count

Fragments with ui	: 8
Activities with ui	: 13
Model Class		: 4
Adapters		: 6
XML Cards		: 4
Menus			: 2

----------------------------------------------------------------